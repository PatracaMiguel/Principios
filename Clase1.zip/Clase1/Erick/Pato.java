public class Pato extends Animal implements Nadar, volar {

    public Pato(String name) {
        super(name);
    }

    @Override
    public void hacerSonido() {
        System.out.println("Cuac Cuac");
    }

    @Override
    public void volar(){
        System.out.println("El pato esta volando");
    }

    @Override
    public void nadar(){
        System.out.println("El pato esta nadando");
    }


}
