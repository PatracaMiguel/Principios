public class Paloma extends Animal implements volar {

    public Paloma(String name) {
        super(name);
    }

     @Override
      void volar(){
          System.out.println("la paloma está volando");
      }

    @Override
    public void hacerSonido() {
        System.out.println("Coo Coo");
    }

}