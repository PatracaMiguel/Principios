interface Nadar {
    void nadar();
}