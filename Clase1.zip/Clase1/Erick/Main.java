

public class Main {
    public static void main(String[] args) {
        Paloma paloma = new Paloma("Erick");
        paloma.hacerSonido();
        paloma.volar();

        Gato gato = new Gato("Pepe");
        gato.hacerSonido();
        gato.getName();
    }
    
}
