public class App {
    public static void main(String[] args) throws Exception {
        
        Perro perro = new Perro(5, "Pepe");
        perro.ladrar();
        perro.comer();
        perro.dormir();
    }
}
