public interface Volador {

    int cantiadadAlas = 2;
    boolean tienePlumas = true;

    void volar();
    
} 






    

