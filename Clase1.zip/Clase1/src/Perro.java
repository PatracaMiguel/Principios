public class Perro {
    private int edad;
    private String nombre;

    public Perro(int edad , String nombre) {
        this.edad = edad;
        this.nombre = nombre;
    }

    public void ladrar() {
        System.out.println("Ladrando...");
    }

    public void comer() {
        System.out.println("Comiendo...");
    }

    public void dormir() {
        System.out.println("Dormir...");
    }

    
}
