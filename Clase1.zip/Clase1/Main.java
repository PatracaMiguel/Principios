import clasesAbstractas.camion;
import clasesAbstractas.Carro;

public class Main {
    public static void main(String[] args) {

        Camion camion = new Camion("Nissan", 4, "Azul", 2);
        camion.encender();
        camion.acelerar();

        Pato miPato = new Pato(5, "Rojo");
        miPato.hacerRuido();
        miPato.volar();

     
    }
    
}
